﻿import networkx as nx

# 从EL构建graph，计算diameter
def diameter(inpath):
    G = nx.Graph()
    file = open(inpath)
    for line in file:
        lines = line.split()
        head, tail = int(lines[0]), int(lines[1])
        G.add_edge(head, tail)
    file.close()
    N = len(G.nodes())
    

    #收集连通子图
    connected=(nx.connected_component_subgraphs(G))
    ds=[]
    for i in connected:
        ds.append(nx.diameter(i))

    #d=连通子图各d的max
    #print('D for Subgraphs are',ds)
    #print(max(ds))
    return (max(ds))


#print(diameter())