import numpy as np
from numpy import *  #导入numpy的库函数
from sklearn.cluster import KMeans
from sklearn.cluster import SpectralClustering
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.multiclass import OneVsRestClassifier
import csv
import matplotlib.pyplot as plt
from matplotlib import cm
from sklearn import metrics

import warnings


warnings.filterwarnings('ignore')

#输入EL输出AM
def ReadEL(filein):
    fin = open(filein,'r')
    #N=number of nodes
    N=0
    f_lines = fin.readlines()
    for line in f_lines:
        line = line.strip()
        vec = line.split()
        if (int(vec[0]) > N):
            N=int(vec[0])
        if (int(vec[1]) > N):
            N=int(vec[1])
    fin.close()
    A = np.zeros((N, N), dtype=int)
    fin = open(filein,'r')
    f_lines = fin.readlines()
    for line in f_lines:
        line = line.strip()
        vec = line.split()
        a,b=int(vec[0])-1,int(vec[1])-1
        A[a][b]=1
        A[b][a]=1
    fin.close()
    return A

# 接收矩阵文件的路径，读取之
def readMatrix(filepath,type):
    infile = open(filepath,'r')
    lines = infile.readlines()
    rows = len(lines)  # 行数
    cols=len(lines[0].strip().split())  # 列数
    #print('Row='+str(rows)+' '+'Cols='+str(cols))
    A = np.zeros((rows, cols), dtype=type)
    A_row=0
    for line in lines:
        line = (line.strip()).split()
        A[A_row:] = line
        A_row += 1
    infile.close()
    return A

#输出list形式的矩阵（array可以tolist()），到txt中
def writeMatrixTxt(matrixlist,filepath):
    outfile=open(filepath,'w')
    for line in matrixlist:
        linestr=''
        if type(line)!=list:
            #print(line,'column=1')
            linestr += str(line)  # for column vector
        else:
            for i in line:
                linestr+=str(i)+'\t'
            linestr=linestr[:-1]+'\n'#'\r\n'
        outfile.write(linestr)
    outfile.close()


#【可视化实验】
# 合并gt路径文件与matrix路径文件
# 将矩阵横向合并，每行表征一个节点，四列分布为：id，label，x，y
def combine(gtpath, matrixpath):
    gtmatrix=readMatrix(gtpath,int)
    #matrix=readMatrix(matrixpath,complex)
    matrix = readMatrix(matrixpath,float)
    if matrixpath=='matrix_GraphWave.txt':
        matrix=readMatrix('matrix_GraphWaveC.txt',complex)
    #print(np.shape(gtmatrix),np.shape(matrix))
    combined=np.hstack((gtmatrix,matrix))
    #print(matrix.shape)
    if matrix.shape[1]!=2:
        print('Columns of',matrixpath,'is',matrix.shape[1],'， should be 2!\n\n')
        return combined
    return combined


# 【可视化实验】
# 接收CSV函数合并的矩阵，作图保存在picpath
def draw(combined,picpath):
    labels = combined[:, 1]
    x_values = combined[:, 2]
    y_values = combined[:, 3]
    #plt.scatter(x_values, y_values, c=labels, cmap='brg', edgecolors='none', s=20) # s=点的尺寸
    plt.scatter(x_values, y_values, c=labels, cmap='viridis', edgecolors='none', s=20)  # s=点的尺寸
    # 设置图表标题并给坐标轴加上标签
    plt.title('Title', fontsize=18)
    plt.xlabel('X', fontsize=14)
    plt.ylabel('Y', fontsize=14)



    # 设置刻度标记的大小
    plt.tick_params(axis='both', which='minor', labelsize=14)
    #plt.tick_params(axis='both', which='major', labelsize=14)
    # 设置每个坐标轴的取值范围
    xmargin=(np.max(x_values)-np.min(x_values))*0.1
    ymargin=(np.max(y_values)-np.min(y_values))*0.1
    plt.axis([(np.min(x_values))-xmargin, np.max(x_values)+xmargin, np.min(y_values)-ymargin, np.max(y_values)+ymargin])
    #plt.show()
    plt.savefig(picpath[:-3]+'png')

# 【可视化实验】
# 可视化实验的主函数，对每个算法的输出进行矩阵拼接+画图的操作
def test_visualize(paths):
    #print("Visualization.")
    for path in paths:
        tmppath = path[6:-3]
        picpath = 'pic' + tmppath + 'eps'
        #print(picpath)
        combined = combine('gt.txt', path)
        draw(combined,picpath)
    print("Visualization finishes.")

# 【聚类】
# 对给定数据，调用kmeans聚类，输出到tmpkmeans_XXX.txt
def cycle_clustering_KMEANS(filepath, K):
    data = readMatrix(filepath,float)
    estimator = KMeans(n_clusters=K)  # 构造聚类器
    estimator.fit(data)  # 聚类
    pred = estimator.labels_  # 获取聚类标签（标签从0开始）
    tmppath = filepath[6:]
    tkpath = 'tmpKmeans' + tmppath
    outfile=open(tkpath,'w')
    index=1
    for i in pred:
        if index==len(pred):
            outfile.write(str(index)+' '+str(i+1))
        else:
            outfile.write(str(index)+' '+str(i+1)+'\n')
        index+=1
    outfile.close()
    return  tkpath,pred

# 【聚类】
# 对给定数据，调用Birch聚类，输出到tmpkmeans_XXX.txt
def cycle_clustering_SpectralClustering(filepath, K):
    data = readMatrix(filepath,float)

    estimator = SpectralClustering(n_clusters = K,affinity='rbf',gamma=0.1)# 构造聚类器

    estimator.fit(data)  # 聚类
    pred = estimator.labels_  # 获取聚类标签（标签从0开始）
    tmppath = filepath[6:]
    tkpath = 'tmpSpectral' + tmppath
    outfile=open(tkpath,'w')
    index=1
    for i in pred:
        if index==len(pred):
            outfile.write(str(index)+' '+str(i+1))
        else:
            outfile.write(str(index)+' '+str(i+1)+'\n')
        index+=1
    outfile.close()
    return  tkpath,pred

# 【聚类】
# 生成matlab的变量path对应的赋值句
def outputMatlabPaths(tkpaths):
    strings="paths=[];\n"
    for tkp in tkpaths:
        strings+="paths=strvcat(paths,'"+tkp+"');\n"
    strings=strings[:-1]
    print(strings)
    outfile=open('000MATLAB.txt','w')
    outfile.write(strings)
    outfile.close()

# 【聚类】
# 【K=标签总数=max-min+1，强制要求gt的标签必须是连续int】
# node clustering的主函数，对每个算法的结果进行聚类，需要后续matlab评估精度
def test_clustering(paths,gtpath,turn=0):
    print("Node clustering.")
    Gt=readMatrix(gtpath,int)
    maxinCol = Gt.argmax(axis=0)  # 各列所在最大值
    mininCol = Gt.argmin(axis=0)  # 各列所在最小值
    K = int(Gt[maxinCol[1], 1])-int(Gt[mininCol[1], 1])+1  # 拿到标签总数
    tkpaths=[]
    scores=[]
    for path in paths:
        print('Kmeans for',path)
        data = readMatrix(path, float)
        tkpath, pred = cycle_clustering_KMEANS(path, K)
        #tkpath, pred = cycle_clustering_SpectralClustering(path, K)
        AMI=metrics.adjusted_mutual_info_score(Gt[:,1], pred) #Adjusted Mutual Information(AMI)
        ARI=metrics.adjusted_rand_score(Gt[:,1], pred) #ARI
        Homo=metrics.homogeneity_score(Gt[:,1], pred)
        Completeness=metrics.completeness_score(Gt[:,1], pred)
        V=metrics.v_measure_score(Gt[:,1], pred)
        if (sum(pred))==0:
            Si=0
        else:
            Si=metrics.silhouette_score(data, pred, metric='euclidean')
        #scores.append([AMI,ARI,Homo,Completeness,V,Si])
        scores.append([AMI, ARI, V, Si])

        tkpaths.append(tkpath)
    #print("Please run pr.m for evaluation:\n")
    #outputMatlabPaths(tkpaths)
    writeMatrixTxt(scores,'00'+str(turn)+'PyCluster.txt')
    #print("\nThe str is above.")

# 【聚类】
# 【K=标签总数=max-min+1，强制要求gt的标签必须是连续int】
# node clustering的主函数，对每个算法的结果进行聚类，需要后续matlab评估精度
def test_clustering2(paths,gtpath,turn=0):
    print("Node clustering.")
    Gt=readMatrix(gtpath,int)
    maxinCol = Gt.argmax(axis=0)  # 各列所在最大值
    mininCol = Gt.argmin(axis=0)  # 各列所在最小值
    K = int(Gt[maxinCol[1], 1])-int(Gt[mininCol[1], 1])+1  # 拿到标签总数
    tkpaths=[]
    scores=[]
    for path in paths:
        print('Spectral for', path)
        data = readMatrix(path, float)
        #tkpath, pred = cycle_clustering_KMEANS(path, K)
        tkpath, pred = cycle_clustering_SpectralClustering(path, K)
        AMI=metrics.adjusted_mutual_info_score(Gt[:,1], pred) #Adjusted Mutual Information(AMI)
        ARI=metrics.adjusted_rand_score(Gt[:,1], pred) #ARI
        Homo=metrics.homogeneity_score(Gt[:,1], pred)
        Completeness=metrics.completeness_score(Gt[:,1], pred)
        V=metrics.v_measure_score(Gt[:,1], pred)
        if (sum(pred))==0:
            Si=0
        else:
            Si=metrics.silhouette_score(data, pred, metric='euclidean')
        #scores.append([AMI,ARI,Homo,Completeness,V,Si])
        scores.append([AMI, ARI, V, Si])

        tkpaths.append(tkpath)
    #print("Please run pr.m for evaluation:\n")
    #outputMatlabPaths(tkpaths)
    writeMatrixTxt(scores,'00'+str(turn)+'PyClusterB.txt')
    #print("\nThe str is above.")

#【升级版role：MirrorRole】
# 从sim矩阵中求取starting点的Top K
def query_TopK(simMatrix,starting,k):
    I = (np.argsort((-simMatrix[starting, :])).tolist())
    topK = np.array(I[:int(k)])  # 注意此时节点标号从0开始
    #print(topK)
    return topK.tolist()

#【升级版role：MirrorRole】
# 将拓扑拷贝并合并，增加新边若干(i,n+i)，i随机取，增加边的数目=原有点数*增加比例
def combine_topo(inpath,outpath,add_ratio):
    A = ReadEL('topo.txt')
    N = np.shape(A)[0]
    infile=open(inpath,'r')
    outfile=open(outpath,'w')
    for line in infile:
        line=line.strip()
        outfile.write(line+'\n')
    infile.close()

    sample = np.arange(1, N+1)
    addnum = int(ceil(N * add_ratio))
    np.random.shuffle(sample)
    sample = sample[:addnum]
    for i in sample:
        outfile.write(str(i)+' '+str(N+i)+'\n')

    #outfile.write(str(N)+' ' + str(N+N) + '\n')
    infile = open(inpath, 'r')
    for line in infile:
        line=(line.strip()).split()
        a,b=int(line[0]),int(line[1])
        outfile.write(str(N+a)+' '+str(N+b)+'\n')
    infile.close()
    outfile.close()
    return N

#【升级版role：MirrorRole】
# scores: # of exact couple / N
def evaluate_role(matrix,N):
    score1, score2= 0.0, 0.0
    for i in range(N):
        top = query_TopK(matrix, i, 3)
        score1+=((i+N)==top[0])
        score2+=((i+N)==top[1])
    score1,score2=score1/N,(score1+score2)/N
    return score1 #[score1,score2]

#【升级版role：MirrorRole】
# Input: featureMatrix(np.array); Output: inner & cos & L2 simMatrix(np.array)
def featureToSim(featureMatrix):
    #内积sim：因为有复向量，所以转置变成共轭转置
    #rawSim = np.matmul(featureMatrix, np.array(np.mat(featureMatrix).H))#T))
    rawSim = np.matmul(featureMatrix, featureMatrix.T)

    #cos sim：mod=cos夹角的分母（列向量矩阵）
    mod = np.mat(np.sqrt(np.diag(rawSim))).T * np.mat(np.sqrt(np.diag(rawSim)))  # 提取sim矩阵对角线，这是模的平方；构建模矩阵，即分母矩阵
    mod[mod == 0] = 0.0001  # 预防除〇错误
    simMatrix = np.divide(rawSim, mod)

    #L2 sim：欧氏距离复向量
    N=np.shape(featureMatrix)[0]
    #L2_d = np.zeros((N, N), dtype=complex)
    L2_d = np.zeros((N, N), dtype=float)
    for i in range(N):
        sub=featureMatrix-np.tile((featureMatrix[i,:]),(N,1)) #求各feature与第i行feature的差：将第i行的特征向量纵向复制变成矩阵，然后featureMatrix减之
        for j in range(i,N):
            #d=complex(np.sqrt(np.matmul(sub[j,:], np.array(np.mat(sub[j,:]).H))))   # T))
            d = float(np.sqrt(np.matmul(sub[j, :], (sub[j, :]).T)))
            L2_d[i,j]=d
            L2_d[j,i]=d
    L2_d[L2_d == 0] = 0.0001  # 预防除〇错误
    #L2 sim = 1 / L2 NORM
    L2_rawsimMatrix = np.divide(np.ones((N,N),float), L2_d)
    #print('L2=',L2_rawsimMatrix)

    cos_simMatrix =   np.array(np.multiply(simMatrix,       np.mat(1 - np.eye(np.shape(featureMatrix)[0]))))  # 对角元素置〇
    inner_simMatrix = np.array(np.multiply(rawSim,          np.mat(1 - np.eye(np.shape(featureMatrix)[0]))))  # 对角元素置〇
    L2_simMatrix =    np.array(np.multiply(L2_rawsimMatrix, np.mat(1 - np.eye(np.shape(featureMatrix)[0]))))  # 对角元素置〇
    return inner_simMatrix ,cos_simMatrix,L2_simMatrix

#【升级版role：MirrorRole】
# Read the embeddings, compute the simMatrix, evaluate the scores, write the scores
def test_role(paths,N,add):
    rolescore=[]
    for path in paths:
        print('For',path)
        #features=readMatrix(path,complex)
        features = readMatrix(path, float)
        np.reshape(features,(N,-1)) #for degree which is always a list
        inner_simMatrix,cos_simMatrix,L2_simMatrix=featureToSim(features)
        #innerscore=evaluate_role(inner_simMatrix,N)
        cosscore = evaluate_role(cos_simMatrix, N)
        L2score =  evaluate_role(L2_simMatrix,N)
        #rolescore.append([innerscore,cosscore,L2score])
        rolescore.append([cosscore, L2score])
    print('Role' + str(add) + ' finishes\n')
    return  rolescore
'''
    writeMatrixTxt(rolescore, '00RoleLab'+str(add)+'.txt')
    print('Role'+str(add)+' finishes\n')
'''



'''
def testmain(paths):
    print('testing...')
    test_classification_MAIN_SDNE(paths, 'gt.txt', 0.5)
    #test_clustering(paths, 'gt.txt')  # 对重叠社区BlogCatalog不能使用
    # test_visualize(paths) # linux 不适用
    rankingcaller(paths)

if __name__ == "__main__":
    paths = ['matrix_deepwalk.txt', 'matrix_LINE.txt',  'matrix_SDNE.txt']#,'matrix_node2vec1.txt','matrix_node2vec2.txt']
    # paths = ['matrix_Sample1.txt', 'matrix_Sample2.txt', 'matrix_Sample3.txt', 'matrix_Sample4.txt']
    # paths = ['matrix_Sample1.txt', 'matrix_Sample2.txt']
    testmain(paths)
'''