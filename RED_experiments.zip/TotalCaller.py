from GraphRoleMain import main_rolx
from GraphWave import main_GraphWave
import test
import warnings
warnings.filterwarnings('ignore')
import tsne
import RoleEmbedding
import numpy as np
from Role2vec import  main_Role2vec
import networkx as nx
from node2vec import main_node2vec
import Degree
'''
# only for dimision = 2
def Visualize():
    paths=RunOur(dim=2, inpath='topo.txt', outpathbasis='matrix_')
    for path in paths:
        test.test_visualize([path])
    paths = RunOther(   dim=2, inpath='topo.txt', outpathbasis='matrix_')
    for path in paths:
        test.test_visualize([path])
def onlyDraw(path):
    test.test_visualize([path])
'''

# combine the topology before testing
# 升级版：
# 1.add_ratio控制增边比例:0,10%,20%...100%
# 2.cos+欧氏距离的倒数
def BigMirrorRole(dim,turn):
    starting=1 #start at 0 or 10%
    for i in range(starting,10+1):
        print('Mirror',str(i))
        add_ratio=float(i)/10
        N=test.combine_topo('topo.txt', 'combined.txt',add_ratio)
        paths = []
        paths = RunOther(dim=dim, inpath='combined.txt', outpathbasis='matrix_')
        paths.extend( RunOur(dim=dim, inpath='combined.txt', outpathbasis='matrix_Q'))
        acc = np.array( test.test_role(paths, N, i) )
        if i==starting:
            cosMatrix = np.reshape(acc[:,0],(-1,1))  # accMatrix: 行=算法，列=ratio
            disMatrix = np.reshape(acc[:,1],(-1,1))  # accMatrix: 行=算法，列=ratio
        else:
            cosMatrix = np.hstack((cosMatrix, np.reshape(acc[:,0],(-1,1)) ))
            disMatrix = np.hstack((disMatrix, np.reshape(acc[:,1],(-1,1)) ))
        #print(np.shape(cosMatrix))
    test.writeMatrixTxt(cosMatrix.tolist(), '00' + str(turn) + 'RoleLabC.txt')
    test.writeMatrixTxt(disMatrix.tolist(), '00' + str(turn) + 'RoleLabD.txt')

# 1.add_ratio=50%
# 2.cos+欧氏距离的倒数
def SmallMirrorRole(dim,turn):
    add_ratio=0.5
    N=test.combine_topo('topo.txt', 'combined.txt',add_ratio)
    paths = []
    paths = RunOther(dim=dim, inpath='combined.txt', outpathbasis='matrix_')
    paths.extend( RunOur(dim=dim, inpath='combined.txt', outpathbasis='matrix_Q'))
    acc=np.array(test.test_role(paths,N,000))
    accMatrix = acc #accMatrix: 行=算法，小列=sim指标
    test.writeMatrixTxt(accMatrix.tolist(),'00'+str(turn)+'RoleLabSmall.txt')




def RunOther(dim=6, inpath='topo.txt',outpathbasis='matrix_'):
    main_rolx.main_rolx(inpath=inpath, outpath=outpathbasis + 'Rolx.txt', dim=dim)
    # paraconfig=[inputpath,dimensions,walk-length,num-walk,w-size,p,q,epoch]
    main_node2vec.main_node2vec([inpath, dim, 80, 10, 10, 1, 2, 100], outpathbasis + 'node2vec')  # p=1, q=2
    main_node2vec.main_node2vec([inpath, dim, 80, 10, 10, 1, 4, 100], outpathbasis + 'node2vec')  # p=1, q=4
    main_Role2vec.main_Role2vec(inpath=inpath, outpath='matrix_Role2vec.txt', dim=dim)
    main_GraphWave.main_GraphWave(inpath=inpath, dim=dim, outpath=outpathbasis+'GraphWave.txt')
    Degree.Degree(inpath=inpath, outpath=outpathbasis+'Degree.txt', dim=dim) ##'matrix_Degree.txt'
    paths = ['matrix_Degree.txt','matrix_node2vec2.txt', 'matrix_node2vec4.txt','matrix_Rolx.txt','matrix_Role2vec.txt','matrix_GraphWave.txt'] #ALL
    #paths = ['matrix_Degree.txt','matrix_node2vec2.txt', 'matrix_node2vec4.txt', 'matrix_Rolx.txt', 'matrix_GraphWave.txt'] #ALL except Role2vec
    #paths = ['matrix_Degree.txt','matrix_Rolx.txt','matrix_Role2vec.txt','matrix_GraphWave.txt'] #ALL except node2vec
    return paths


def RunOur(dim=6, inpath='topo.txt', outpathbasis='matrix_'):

    d1=int(0.5*dim) #################################################################################################################
    if d1>dim:
        print('d1 should < dim')
        exit(1)

    paths=[]
    print("RED starts")
    paths.extend( RoleEmbedding.RoleEmbeddingD(inpath,outpathbasis,dim,d1) )
    return paths


def runTest(paths,dim,turn):
    ###tsne.test_highvisualize(paths)
    #test.test_clustering(paths, 'gt.txt',turn)
    #test.test_clustering2(paths, 'gt.txt',turn)
    SmallMirrorRole(dim,turn)
    #BigMirrorRole(dim,turn)


def Cycle_Caller(turn):
    #print('All Start')
    dim=6 #6 for all, 20 for parameter
    paths=[]
    #paths = RunOther(    dim=dim, inpath='topo.txt', outpathbasis='matrix_')
    #paths.extend( RunOur(dim=dim, inpath='topo.txt', outpathbasis='matrix_Q') )
    runTest(paths,dim,turn)

def Parameter_Caller(turnnum):
    print("Para starts")
    dim=20 #20 for parameter
    for d1 in range(0,dim+1):
        print("\nd1=",d1)
        for turn in range(turnnum):
            paths = []
            print("\nd1=", d1,"\nturn=",turn)
            paths.extend(RoleEmbedding.RoleEmbeddingD(inpath='topo.txt', outpath='matrix_Q', dim=dim, d1=d1))
            test.test_clustering(paths, 'gt.txt',turn)
            test.test_clustering2(paths, 'gt.txt',turn)
        aver_para(0, turnnum, d1)
        aver_para(1, turnnum, d1)

    accumulate_para(dim, 0)
    accumulate_para(dim, 1)
    print("Para ends")

def accumulate_para(dim,index):
    paths = ['PyCluster.txt', 'PyClusterB.txt', 'RoleLabSmall.txt', 'RoleLabC.txt', 'RoleLabD.txt']
    pathbasis = paths[index]

    rows = dim+1  # 行数
    cols = 4  # 列数
    # print('Row='+str(rows)+' '+'Cols='+str(cols))
    accM = np.zeros((rows, cols), dtype=float)
    for i in range(dim+1):
        accM[i,:]=test.readMatrix('AA'+str(i)+ pathbasis, float)
    test.writeMatrixTxt(accM.tolist(), 'AAaaAA' + pathbasis)

def aver_para(index,turnnum,d1):
    paths=['PyCluster.txt','PyClusterB.txt','RoleLabSmall.txt','RoleLabC.txt','RoleLabD.txt']
    pathbasis=paths[index]
    aver = test.readMatrix('000'+pathbasis, float)
    aver = aver * 0
    for i in range(turnnum):
        aver=aver+test.readMatrix('00'+str(i)+pathbasis, float)
    aver=aver/(turnnum+0.0)
    test.writeMatrixTxt(aver.tolist(), 'AA'+str(d1)+ pathbasis)

def aver(index,turnnum):
    paths=['PyCluster.txt','PyClusterB.txt','RoleLabSmall.txt','RoleLabC.txt','RoleLabD.txt']
    pathbasis=paths[index]
    aver = test.readMatrix('000'+pathbasis, float)
    aver = aver * 0
    for i in range(turnnum):
        aver=aver+test.readMatrix('00'+str(i)+pathbasis, float)
    aver=aver/(turnnum+0.0)
    test.writeMatrixTxt(aver.tolist(), 'AA'+ pathbasis)


def turnCaller():
    turnnum=10
    for i in range(0,turnnum):
        print('\nTURN '+str(i)+'\n')
        Cycle_Caller(i)

    #Parameter_Caller(turnnum)

    #aver(0,turnnum) #聚类
    #aver(1,turnnum) #聚类2

    aver(2,turnnum) #小mirror

    #aver(3,turnnum) #大mirror
   # aver(4,turnnum) #大mirror


if __name__ == "__main__":
    turnCaller()
    #Cycle_Caller(0)

