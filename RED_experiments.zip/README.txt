Main file: TotalCaller.py
Please choose the corresponding function to conduct experiments:
Role detection (Kmeans): 		test.test_clustering()
Role detection (Spectral Clustering): 		test.test_clustering2()
Role-equivalency identification: 		SmallMirrorRole()
Robustness: 		BigMirrorRole()

Please check the folder "updated libs" to keep word2vec going.